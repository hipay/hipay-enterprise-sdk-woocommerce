<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class that handles ING Home'Pay payment method.
 * @extends WC_HipayEnterprise
 * @since 1.0.0
 */
class WC_HipayEnterprise_LocalPayments_Inghomepay extends WC_HipayEnterprise {

}
