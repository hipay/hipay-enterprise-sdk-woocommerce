<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class that handles iDEAL payment method.
 * @extends WC_HipayEnterprise
 * @since 1.0.0
 */
class WC_HipayEnterprise_LocalPayments_Ideal extends WC_HipayEnterprise {

}
