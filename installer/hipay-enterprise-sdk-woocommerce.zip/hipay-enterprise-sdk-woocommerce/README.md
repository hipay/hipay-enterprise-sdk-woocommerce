# HiPay Enterprise plugin for Woocommerce 3.x.x

